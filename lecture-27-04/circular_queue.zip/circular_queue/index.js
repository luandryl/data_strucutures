import CircularQueue from './data_structures/CircularQueue'

const users = [
    {
        name: 'Archer',
        email: 'archer@test.com',
        _id: 3
    },
    {
        name: 'Batman',
        email: 'batman@test.com',
        _id: 2
    },
    {
        name: 'Luke',
        email: 'luke@test.com',
        _id: 1
    }
]

console.log("Enqueue user list")
const userL = new CircularQueue()
users.forEach( u => {
    userL.enQueue(u);
});
userL.printList()

console.log("\n")
console.log("Search element by data._id")
console.log(userL.search(2));

console.log("\n")
console.log("Dequeue user list")
userL.deQueue()
userL.printList()