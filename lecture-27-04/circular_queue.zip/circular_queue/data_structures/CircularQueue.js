class Node {
    constructor(data) {
        this.data = data;
        this.next = null;
    }
}

export default class CircularQueue {

    constructor () {
        this.start = null;
        this.end = null;
        this.size = 0;
    }

    enQueue (data) {

        const newNode = new Node(data);

        if (this.size === 0) {
            this.start = this.end = newNode;
            newNode.next = newNode;
        } else {
            newNode.next = this.end.next;
            this.end.next = newNode;
            this.end = newNode;
        }

        this.size += 1;

    }

    deQueue () {
        if (this.size > 0) {
            let tmp = this.start;
            this.start = this.start.next;
            this.end.next = this.start;
            this.tmp = null;
            this.size -= 1;
        }
        
    }

    search (e) {
        let tmp = this.start;
        let i = 0;

        if (this.size === 0) 
            throw new Error({err: "Empty"})
        
        while(i < this.size && tmp.data._id != e) {
            tmp = tmp.next;
            i++;
        }

        return tmp.data;
    }

    printList () {
        let tmp = this.start;
        let i = 0;
        while(i < this.size) {
            console.log(tmp.data)
            tmp = tmp.next;
            i++;
        }
    }

}