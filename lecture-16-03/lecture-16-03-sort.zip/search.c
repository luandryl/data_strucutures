#include <stdio.h>

int searchR (int element, int size, int v[]) {

    if (v[size-1] == element) { // asks if its be the last index
        return size-1; // return the last element
    }
    else {
        /* 
            asks if we still in the boundaries of array
            then call the recursiion;
        */
        return (size == -1) ? -1 : searchR(element, size-1, v);
    }
        

}
int main () {

    int v[4] = {1, 5, 10, 12};
    printf("Position: [%d]", searchR(10, 4, v));
}